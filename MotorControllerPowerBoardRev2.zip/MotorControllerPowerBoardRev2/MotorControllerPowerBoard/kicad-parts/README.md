# kicad-parts
Kicad modules and footprints for supermileage should be included as a submodule for all supermileage projects. Any custom components should be added here.
